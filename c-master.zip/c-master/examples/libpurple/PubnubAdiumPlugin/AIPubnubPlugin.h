//
//  PubnubAdiumPlugin.h
//  PubnubAdiumPlugin
//
//  Created by Alexey Yesipenko on 4/28/13.
//  Copyright (c) 2013 Alexey Yesipenko. All rights reserved.
//

#import "Adium/AIPlugin.h"

@interface AIPubnubPlugin : NSObject

@end
