//
//  ESPurplePubnubAccount.h
//  PubnubAdiumPlugin
//
//  Created by Alexey Yesipenko on 5/2/13.
//  Copyright (c) 2013 Alexey Yesipenko. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <AdiumLibpurple/CBPurpleAccount.h>

@interface ESPurplePubnubAccount : CBPurpleAccount


@end
