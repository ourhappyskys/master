//
//  ESPubnubService.h
//  PubnubAdiumPlugin
//
//  Created by Alexey Yesipenko on 5/2/13.
//  Copyright (c) 2013 Alexey Yesipenko. All rights reserved.
//

#import <AdiumLibpurple/PurpleService.h>

@interface ESPubnubService : PurpleService

@end
