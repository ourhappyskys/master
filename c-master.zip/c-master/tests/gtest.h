#ifndef _PUBNUB_GTEST
#define _PUBNUB_GTEST

#include <stdio.h>

#ifdef _MSC_VER
#include <tchar.h>
#define _VARIADIC_MAX 10
#endif // _WIN32

#include "gtest/gtest.h"

#endif // _PUBNUB_GTEST