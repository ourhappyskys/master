#ifndef _PUBNUB_ITESTING
#define _PUBNUB_ITESTING

#include <stdio.h>

#ifdef _MSC_VER
#include <tchar.h>
#define _VARIADIC_MAX 10
#endif // _MSC_VER

#include "gtest/gtest.h"

#endif // _PUBNUB_ITESTING